
from abc import ABC, abstractmethod

class LLMBackend(ABC):
    @abstractmethod
    def query(self, prompt: str) -> str:
        pass
