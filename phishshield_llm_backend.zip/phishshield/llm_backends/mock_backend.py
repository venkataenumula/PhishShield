
from .base import LLMBackend

class MockBackend(LLMBackend):
    def query(self, prompt: str) -> str:
        return f"[MOCKED RESPONSE] You asked: {prompt}"
