
import requests
from .base import LLMBackend

class OllamaBackend(LLMBackend):
    def __init__(self, host, model):
        self.host = host
        self.model = model

    def query(self, prompt):
        response = requests.post(f"{self.host}/api/generate", json={
            "model": self.model,
            "prompt": prompt
        })
        return response.json().get("response", "").strip()
