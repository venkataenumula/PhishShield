
import yaml
from .ollama_backend import OllamaBackend
from .vllm_backend import VLLMBackend
from .mock_backend import MockBackend

def load_backend():
    with open("phishshield/config.yaml") as f:
        config = yaml.safe_load(f)
    
    backend = config["llm_backend"]
    
    if backend == "ollama":
        return OllamaBackend(**config["ollama"])
    elif backend == "vllm":
        return VLLMBackend(**config["vllm"])
    elif backend == "mock":
        return MockBackend()
    else:
        raise ValueError(f"Unsupported LLM backend: {backend}")
