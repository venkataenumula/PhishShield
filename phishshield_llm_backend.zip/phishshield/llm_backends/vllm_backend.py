
import requests
from .base import LLMBackend

class VLLMBackend(LLMBackend):
    def __init__(self, host, api_key=None):
        self.host = host
        self.headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}

    def query(self, prompt):
        payload = {
            "model": "llama3",
            "messages": [
                {"role": "system", "content": "You are a phishing detection assistant."},
                {"role": "user", "content": prompt}
            ]
        }
        response = requests.post(f"{self.host}/chat/completions", json=payload, headers=self.headers)
        return response.json()["choices"][0]["message"]["content"]
