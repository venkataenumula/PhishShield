
from llm_backends import load_backend

llm = load_backend()

def analyze_text(text):
    return llm.query(text)

if __name__ == "__main__":
    prompt = "Detect phishing in the following message: 'Reset your password urgently at fakebank.com'"
    print(analyze_text(prompt))
