# Base model wrapper for phishing classifier
