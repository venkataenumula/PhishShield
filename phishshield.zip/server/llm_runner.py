# Sends prompts to vLLM or Ollama backend
