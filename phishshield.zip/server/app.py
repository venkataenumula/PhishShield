# FastAPI app entrypoint placeholder
