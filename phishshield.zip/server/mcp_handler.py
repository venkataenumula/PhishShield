# Handles MCP-formatted requests
