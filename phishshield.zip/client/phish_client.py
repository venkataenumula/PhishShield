# Client SDK for submitting messages to the inference server
